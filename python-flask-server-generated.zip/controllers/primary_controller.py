
def get_primary() -> str:
    return 'do some magic!'

def post_primary(problem) -> str:
    return 'do some magic!'
