
def get_analytic() -> str:
    return 'do some magic!'

def post_analytic(problem) -> str:
    return 'do some magic!'
